
print 'Address of a is: {}'.format(id(a))

# a[0] = ''
# print a
# print 'Address of a is: {}'.format(id(a))