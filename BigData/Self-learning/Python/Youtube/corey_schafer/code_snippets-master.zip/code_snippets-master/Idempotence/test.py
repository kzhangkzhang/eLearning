# f(x)
# add_ten(num)
def add_ten(num):
    return num + 10

# f(f(x))   =  f(x)
#   f(f(10)) = 30 | f(10) = 20
# print add_ten(add_ten(10))

print abs(abs(abs(-10)))
# abs(-10) == 10
# abs(10) == 10
# abs(10) == 10

a = 10