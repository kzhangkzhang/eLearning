
condition = 'Test'

if condition:
    print('Evaluated to True')
else:
    print('Evaluated to False')
