
courses = ['History', 'Math', 'Physics', 'CompSci']
